CREATE VIEW [ClientesDairyProducts] AS
SELECT DISTINCT C.CustomerID, UC.[Ultima Compra], PC.[Primera Compra] FROM Customers AS[C]
	INNER JOIN Orders AS[O] ON C.CustomerID = O.CustomerID
	INNER JOIN [Order Details] AS[OD] ON O.OrderID = OD.OrderID
	INNER JOIN Products AS[P] ON OD.ProductID = P.ProductID
	INNER JOIN Categories AS[Ca] ON P.CategoryID = Ca.CategoryID
	INNER JOIN UltimaCompra AS[UC] ON C.CustomerID = UC.CustomerID
	INNER JOIN PrimeraCompra AS[PC] ON C.CustomerID = PC.CustomerID
WHERE Ca.CategoryID = 4
go

