CREATE VIEW Diferencia AS(
SELECT V97.ProductName, (V96.Ventas96*100)/V97.Ventas97 AS[Porcentaje] FROM VentasDel96 AS[V96]
	INNER JOIN VentasDel97 AS[V97] ON V96.ProductName = V97.ProductName
)
go

