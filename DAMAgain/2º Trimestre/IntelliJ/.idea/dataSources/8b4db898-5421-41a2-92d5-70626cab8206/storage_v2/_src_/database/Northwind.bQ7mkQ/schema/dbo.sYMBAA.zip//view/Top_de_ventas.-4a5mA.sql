CREATE VIEW [Top de ventas] AS
	SELECT Año, MAX(Ventas) AS [Ventas maximas]
	FROM [Ventas de productos por año]
	GROUP BY Año
go

