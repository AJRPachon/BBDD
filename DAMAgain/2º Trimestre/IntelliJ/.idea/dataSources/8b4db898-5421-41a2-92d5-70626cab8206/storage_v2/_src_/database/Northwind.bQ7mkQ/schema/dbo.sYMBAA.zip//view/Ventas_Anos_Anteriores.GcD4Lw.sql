CREATE VIEW [Ventas Años Anteriores] AS
	SELECT SUM(OD.Quantity*UnitPrice) AS[Ventas], YEAR(OA.OrderDate) AS [Años Anteriores], E.EmployeeID FROM Employees AS E
		INNER JOIN Orders AS O ON E.EmployeeID = O.EmployeeID
		INNER JOIN [Order Details] AS OD ON O.OrderID = OD.OrderID
		INNER JOIN Orders AS OA ON O.EmployeeID = O.EmployeeID
		WHERE YEAR(o.OrderDate) > YEAR(OA.OrderDate)
	GROUP BY  E.EmployeeID, year(OA.OrderDate)
go

