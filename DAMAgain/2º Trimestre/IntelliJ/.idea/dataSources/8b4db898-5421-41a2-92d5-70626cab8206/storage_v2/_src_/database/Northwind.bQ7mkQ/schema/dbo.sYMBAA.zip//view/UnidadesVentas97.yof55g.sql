CREATE VIEW [UnidadesVentas97] AS
SELECT SUM(OD.Quantity) AS[Ventas], P.ProductID, P.ProductName FROM Products AS[P]
	INNER JOIN [Order Details] AS[OD] ON P.ProductID = OD.ProductID
	INNER JOIN Orders AS[O] ON OD.OrderID = O.OrderID
WHERE YEAR(O.OrderDate) = 1997
GROUP BY P.ProductID, P.ProductName
go

