CREATE VIEW [Ventas del 97] AS
SELECT P.ProductName, SUM(OD.Quantity*OD.Quantity)AS[Ventas 97] FROM Products AS[P]
	INNER JOIN [Order Details] AS[OD] ON P.ProductID = OD.ProductID
	INNER JOIN Orders AS[O] ON OD.OrderID = O.OrderID
		WHERE YEAR(OrderDate) = 1997
			GROUP BY P.ProductName
go

