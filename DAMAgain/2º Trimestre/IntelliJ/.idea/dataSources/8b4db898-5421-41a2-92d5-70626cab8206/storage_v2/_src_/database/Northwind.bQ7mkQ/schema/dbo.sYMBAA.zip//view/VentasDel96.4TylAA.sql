CREATE VIEW  [VentasDel96] AS
SELECT P.ProductName, SUM(OD.Quantity*OD.Quantity)AS[Ventas96] FROM Products AS[P]
	INNER JOIN [Order Details] AS[OD] ON P.ProductID = OD.ProductID
	INNER JOIN Orders AS[O] ON OD.OrderID = O.OrderID
		WHERE YEAR(OrderDate) = 1996
			GROUP BY P.ProductName
go

