CREATE VIEW [PrimeraCompra] AS
SELECT DISTINCT MIN(O.OrderDate) AS[Primera Compra], C.CustomerID FROM Customers AS[C]
	INNER JOIN Orders AS[O] ON C.CustomerID = O.CustomerID
	INNER JOIN [Order Details] AS[OD] ON O.OrderID = OD.OrderID
	INNER JOIN Products AS[P] ON OD.ProductID = P.ProductID
	INNER JOIN Categories AS[Ca] ON P.CategoryID = Ca.CategoryID
WHERE Ca.CategoryID = 4
GROUP BY C.CustomerID
go

