CREATE VIEW [Ventas Año] AS
SELECT SUM(OD.Quantity*UnitPrice) AS[Ventas],YEAR(O.OrderDate) AS [Año], E.EmployeeID FROM Employees AS E
	INNER JOIN Orders AS O ON E.EmployeeID = O.EmployeeID
	INNER JOIN [Order Details] AS OD ON O.OrderID = OD.OrderID
GROUP BY  E.EmployeeID, YEAR(OrderDate)
--ORDER BY E.EmployeeID,Año
go

