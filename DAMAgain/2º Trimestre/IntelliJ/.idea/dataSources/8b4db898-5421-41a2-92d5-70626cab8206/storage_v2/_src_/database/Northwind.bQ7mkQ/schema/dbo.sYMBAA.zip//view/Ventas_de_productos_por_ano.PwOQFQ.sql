CREATE VIEW [Ventas de productos por año] AS
	SELECT P.ProductName, C.CategoryName, YEAR(O.OrderDate) AS Año, SUM(OD.UnitPrice * OD.Quantity) AS Ventas
	FROM Products AS P
	INNER JOIN Categories AS C ON C.CategoryID = P.CategoryID
	INNER JOIN [Order Details] AS OD ON OD.ProductID = P.ProductID
	INNER JOIN Orders AS O ON O.OrderID = OD.OrderID
	GROUP BY P.ProductName, C.CategoryName, YEAR(O.OrderDate)
go

