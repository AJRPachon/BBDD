CREATE TRIGGER NoMasDeDiez ON [Order Details] AFTER INSERT, UPDATE AS
BEGIN
	IF EXISTS (SELECT * FROM [Order Details] --Tenemos que tener en cuenta los que ya habia de antes.
				WHERE OrderID IN(SELECT OrderID FROM inserted)
				GROUP BY ORDERID
				HAVING COUNT(DISTINCT ProductID) > 10)
	BEGIN
		ROLLBACK
	END --Fin_si
END
go

